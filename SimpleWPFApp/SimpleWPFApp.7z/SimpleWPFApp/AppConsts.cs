﻿namespace SimpleWPFApp
{
    internal static class AppConsts
    {
        public const string LoadPackages = "LoadPackages";
        public const string SavePackages = "SavePackages";
        public const string AppTitle = "SIMPLE WPF APP";
    }
}
