﻿using SimpleWPFApp.Model;
using SimpleWPFApp.ViewModel;
using System.Windows;

namespace SimpleWPFApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
