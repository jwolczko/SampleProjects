﻿namespace WebApp.Dto
{
    public class RecipientDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }
}
